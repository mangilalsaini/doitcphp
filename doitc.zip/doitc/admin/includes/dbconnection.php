<?php
    session_start();

    $hostname = "localhost";
    $dbuser = "root";
    $dbpass = '';
    $dbname = "doitc";

    $conn = mysqli_connect($hostname, $dbuser, $dbpass, $dbname);
    if(mysqli_connect_errno()){
        die("Database Error Encountered : " . mysqli_connect_errno());
    }
                                   
?>