<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forms</title>
    <!-- css not used
        <style>
    
            table tr td{
                border: 2px solid red;
            }

        </style>
    -->
</head>
<body>
    <form action="welcome.php" method="get">
        <label for="star" style="color: red;">* required fields......</label>
        <table>
            <tr>
                <td>
                    <label for="name">Enter Your Name </label>
                </td>
                <td>
                    <label for="collen"> : </label>
                </td>
                <td>
                    <input type="text" name="name" required placeholder="enter name">
                    <label for="star" style="color: red;"> * </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="email">Enter Email </label>
                </td>
                <td>
                    <label for="collen"> : </label>
                </td>
                <td>
                    <input type="email" name="email" required placeholder="enter email">
                    <label for="star" style="color: red;"> * </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="username">User Name </label>
                </td>
                <td>
                    <label for="collen"> : </label>
                </td>
                <td>
                    <input type="text" name="username" required placeholder="enter user name">
                    <label for="star" style="color: red;"> * </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="password">Password </label>
                </td>
                <td>
                    <label for="collen"> : </label>
                </td>
                <td>
                    <input type="password" name="password" required placeholder="enter password">
                    <label for="star" style="color: red;"> * </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="gender">Gender </label>
                </td>
                <td>
                    <label for="collen"> : </label>
                </td>
                <td>
                    <input type="radio" name="gender" required value="Male">Male
                    <input type="radio" name="gender" required value="Female">Female
                    <input type="radio" name="gender" required value="Other">Other
                    <label for="star" style="color: red;"> * </label>
                </td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: center;">
                    <input type="submit" name="Submit" value="Submit">
                </td>
            </tr>
        </table>
    </form>
    
</body>
</html>