<?php
    $name =  $_REQUEST['name'];
    $email = $_REQUEST['email'];

    echo "Welcome ! <b style='color:red'>$name</b> Your Email Addrass is : <b4 style='color:red'>$email</b4>";
?>