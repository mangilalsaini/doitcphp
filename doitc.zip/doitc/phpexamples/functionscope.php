<?php
  /*
    $x = 10;
    $y = 20;

    function getaddition() {
        global $x, $y;
        $x = 55;
        $y = 45;
        echo "Afer calling function value no x : $x<br>";
        echo "value no y : $y<br>";
        

    }

    echo "Before Calling of function value no x : $x<br>";
    echo "value no y : $y<br>";

    getaddition($x, $y);
*/

$a = [10, 20, 30, 40, 10, 35, 20];
$b = 5;
/*checking a variable is array or not

echo var_dump(is_array($a)). "<br>";
echo var_dump(is_array($b)). "<br>";

// counting number of elements in array
echo "number of elements in array are : ". count($a);

//search a number in array

echo "<br>3 is in array ";
echo var_dump(in_array(3, $a)). "<br>";

// unique elements in array
$arr_unique = array_unique($a);
print_r($arr_unique);

// search a element in array

echo "<br>". array_search(10,$a);
$fruits = ['apple', 'banana', 'mango', 'orange'];

echo "<br>". array_search('apple', $fruits);
--------------------------------*/

//searcj element in arrary repeated

$element = 10;
for($i=0; $i < count($a); $i++) {
      if($a[$i] == $element) {
        echo "$element index is $i <br>";
      }
  }


/*------------- Reverse Array-------------

for($i=0; $i< count($a); $i++) {
  echo $a[$i]. "<br>";
}
echo "-----------------------<br>";
for($i=count($a)-1; $i>=0;$i--) {
  echo $a[$i]. "<br>";
}

//------------------Array Reverse in another array ---------------
$j = 0;
for($i=count($a)-1; $i>=0;$i--) {
  $arr_rev[] = $a[$i];
  $j++;
}
echo "<pre>";
print_r($arr_rev);
echo "</pre>";

//print reverse arry in php with inbuild functioj

$arr = [1, 2, 3, 4, 5];
$arr = array_reverse($arr);
echo "<pre>";
print_r($arr);
echo "</pre>";
*/

$fruitsname = ['Apple','Banana','Orange','Mango','Kiwi'];

foreach($fruitsname as $index=>$fruit){
  $arr_length [] = strlen($fruit);
  //echo "$index - $fruit - " . strlen($fruit). " <br>";
}
echo "<pre>";
print_r($arr_length);
echo "</pre>";

//------------------Arrary Elements Factorial-------  
/*
$arr = [2, 3, 4, 5, 6];
$fact = 1;
foreach($arr as $arr_value) {
  for($i=$arr_value; $i>1; $i--) {
    $fact = $fact * $i;
  }
  echo "Factorial of $arr_value is : $fact <br>";
  $fact = 1;
}



function strlength($item){
  return strlen($item);
}

$result = array_map('strlength', $fruitsname);

echo "<pre>";
print_r($result);
echo "</pre>";

$arr1 = ['mohan', 'Das', 'ram'];
$arr2 = ['Mohan', 'Das', 'Man'];
$result = array_diff($arr1, $arr2);

echo "<pre>";
print_r($result);
echo "</pre>";
echo ucfirst("mangilal");
*/
$arr1 = ['mohan', 'Das', 'ram'];
$arr2 = ['Mohan', 'Das', 'Man'];
$result = array_diff($arr1, $arr2);

echo "<pre>";
print_r($result);
echo "</pre>";
?>