<?php
        $id = 4;

        switch($id){
            case 1 :
                echo "ID is 1";
                break;
            case 2 :
                echo "ID is 2";
                break;
            case 3 :
                echo "ID is 3";
                break;
            default :
                echo "ID is not under range";
                break;
        }
?>