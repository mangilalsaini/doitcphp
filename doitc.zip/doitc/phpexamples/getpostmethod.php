<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get_Post</title>
</head>
<body>
    <form method="GET" action="<?php echo $_SERVER['PHP_SELF'] ?>">
        <label> Enter Your Name : </label>    
        <input type="text" name="name">
        <input type="submit" name="Submit" value="Submit">

        <?php
            if($_SERVER['REQUEST_METHOD'] == 'POST'|| $_SERVER['REQUEST_METHOD'] == 'GET') {
                $name = $_REQUEST['name'];
                print_r($name);

        //--------------print server information--------        
                echo "<pre>";
                    print_r($_SERVER);
                echo "</pre>";
            }
            else {
                echo "<BR>Server metho POST not selected";
            }
        ?>
    </form>
    
</body>
</html>