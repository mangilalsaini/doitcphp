<?php
    echo "Information about collage";
?>