<?php
//--------------foreach loop example
         $fruitsname = ['Apple','Banana','Orange','Mango','Kiwi'];

         foreach($fruitsname as $index=>$fruit){
            echo "$index - $fruit <br>";
         }



?>