<?php
    //-------------super Global Variables with function

    $x = 45;
    $y = 15;
    $z = 0;

    function getaddition() {
    $GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
    }
    getaddition();
    echo "Sum : $z";
?>
