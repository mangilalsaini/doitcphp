<?php include_once("includes/header.php"); ?>
      <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>
                <!---Blog Post---------->

                <?php include_once("includes/blogpost.php"); ?>

                <!-- Pager -->
                <?php include_once("includes/pager.php"); ?>

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include_once("includes/sidebar.php"); ?>

        </div>
        <!-- /.row -->

        <hr>
<?php include_once("includes/footer.php"); ?>
