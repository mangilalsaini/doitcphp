<?php
    session_start();

    $_SESSION["name"] = "Mangilal";
    $_SESSION["number"] = 10;

    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";
?>