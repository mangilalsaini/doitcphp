<?php
    $hostname = "localhost";
    $username = "root";
    $password = '';
    $database = "doitc";

    $conn = mysqli_connect($hostname, $username, $password, $database);
    if(mysqli_connect_errno()){
        echo "Database Error Encountered : " . mysqli_connect_errno();
    }
    else{
        $query = "SELECT * FROM users";
        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_assoc($result)){
            echo $row['reg_id'] . " - " . $row['fname'] . " - ". $row['lname'] . "<br>";
        }
    }
?>