<?php
    $x = 10;
    $y = 20;

    function getaddition(&$num1, &$num2) {
        echo "value no num1 : $num1<br>";
        echo "value no num2 : $num2<br>";
        $num1 = 100;
        $num2 = 200;

    }

    getaddition($x, $y);

    echo "value no x : $x<br>";
    echo "value no y : $y";
?>